from django.shortcuts import render
from dj_rest_auth.app_settings import api_settings
from dj_rest_auth.utils import jwt_encode
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from dj_rest_auth.registration.views import RegisterView,LoginView
from rest_framework.permissions import IsAuthenticated,AllowAny
from rest_framework.decorators import permission_classes
from rest_framework_simplejwt.tokens import RefreshToken
from app.serializers import UserSerializer, PostSerializer
from app.models import Post
import time
# import updateview
# from .models import UserManagement, Post
# from .serializers import UserSerializer, PostSerializer
from rest_framework import viewsets
# from rest_framework.permissions import IsAuthenticated
# from rest_framework.decorators import action
# from rest_framework.response import Response
# from rest_framework import status
# from rest_framework_simplejwt.tokens import RefreshToken


# Create your views here.

@api_view(['GET'])
def index(request):
    return render(request, 'index.html')

class CustomLoginView(LoginView):
    
    def post(self, request, *args, **kwargs):
        username = request.data.get("username")
        password = request.data.get("password")
        if username == '' or password == '':
            return Response({"message": "Username and password are required"}, status=status.HTTP_400_BAD_REQUEST)
            
        self.request = request
        self.serializer = self.get_serializer(data=request.data)
        self.serializer.is_valid(raise_exception=True)
        self.login()
        user = self.user
        user_serializer = UserSerializer(user)
        refresh = RefreshToken.for_user(user)
        access_token = refresh.access_token
        data = {
            "access_token": str(access_token),
            "refresh_token": str(refresh),
            "user": user_serializer.data  # Corrected this line
        }
        return Response(data, status=status.HTTP_200_OK)


class CustomRegisterView(RegisterView):
    

    def create(self, request, *args, **kwargs):
        username = request.data.get("username")
        email = request.data.get("email")
        password1 = request.data.get("password1")
        password2 = request.data.get("password2")
        fullname = request.data.get("fullname")
        # Check if fields are empty or not
        if username == None:
            return Response({"message": "Username is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            self.perform_create(serializer)
        except Exception as e:
            return Response({"message": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(
            {
                "message": "User registered successfully",
            },
            status=status.HTTP_200_OK,
            headers=self.get_success_headers(serializer.data),
        )

    def perform_create(self, serializer):
        user = serializer.save(self.request)
        if api_settings.USE_JWT:
            self.access_token, self.refresh_token = jwt_encode(user)
        elif not api_settings.SESSION_LOGIN:
            api_settings.TOKEN_CREATOR(self.token_model, user, serializer)
        return user
    
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def all_posts(request):
    posts = Post.objects.all()
    serializer = PostSerializer(posts, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_post(request):
    title = request.data.get("title")
    description = request.data.get("description")
    if title == None or description == None:
        return Response({"message": "Title and description are required"}, status=status.HTTP_400_BAD_REQUEST)
    # get file from request
    image = request.FILES.get("image")
    try:
        data = data = request.data
        data['author'] = request.user.id
        serializer = PostSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
    except Exception as e:
        return Response({"message": str(e)}, status=status.HTTP_400_BAD_REQUEST)


    return Response("Post created successfully")


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def my_posts(request):
    time.sleep(5)
    my_posts = Post.objects.filter(author=request.user)
    serializer = PostSerializer(my_posts, many=True)
    return Response(serializer.data)

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_post(request, pk):
    post = Post.objects.get(id=pk)
    title = request.data.get("title")
    description = request.data.get("description")
    if title == None or description == None:
        return Response({"message": "Title and description are required"}, status=status.HTTP_400_BAD_REQUEST)
    post.title = title
    post.description = description
    post.save()
    return Response("Post updated successfully")

@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_post(request, pk):
    post = Post.objects.get(id=pk)
    post.delete()
    return Response("Post deleted successfully")

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def logout_view(request):
    request.user.auth_token.delete()
    return Response({"message": "User logged out successfully"}, status=status.HTTP_401_UNAUTHORIZED)