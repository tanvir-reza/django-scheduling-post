from django.contrib import admin
from .models import UserManagement, Post

admin.site.register(UserManagement)
admin.site.register(Post)
